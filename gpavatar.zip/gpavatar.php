<?php
/*
Plugin Name: Import Posts From G+
Plugin URI: 
Description: Get posts from google plus and import to wordpress 
Version: 1.0.0
Author: Totden, Mirtho 
*/
register_activation_hook(__FILE__, 'my_activation');
add_action('my_hourly_event', 'do_this_hourly');
function my_activation() {
	wp_schedule_event( current_time( 'timestamp' ), 'hourly', 'my_hourly_event');
}
function do_this_hourly() {
	$result = exec("python plus.py");
}
