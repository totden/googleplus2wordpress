EMBEDLY_KEY = 'e3a2173ba56a43e583b17bb99e216b47'

# TODO Make less constanty
WORDPRESS_XMLRPC_URI = 'http://tinnhanhviet.net/xmlrpc.php'
WORDPRESS_USERNAME = 'strong1692'
WORDPRESS_PASSWORD = '*99856215*.01'
# Does not work for wordpress.com - http://en.forums.wordpress.com/topic/xml-rpc-anonymous-comments-wordpresscom?replies=18
# WORDPRESS_COMMENT_STYLE = 'me'
WORDPRESS_COMMENT_STYLE = 'non-anonymous'
